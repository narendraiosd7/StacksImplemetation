import UIKit

//MARK: - Array
class Stack<T> {
    
    var array = [T]()
    
    func push(value: T) {
        array.append(value)
    }
    
    func pop() -> T? {
        return array.removeLast()
    }
    
    func peek() -> T? {
        return array.last
    }
    
    func isEmpty() -> Bool {
        return array.isEmpty
    }
}


let stack = Stack<Int>()
stack.push(value: 8)
stack.push(value: 2)
stack.push(value: 7)

stack.pop()

stack.peek()

stack.isEmpty()

//MARK: - LinkedList

class LLStack<T> {
    var data: T
    var next: LLStack?
    
    init(val: T) {
        data = val
    }
}

class LLStackImplemetation<T> {
    var top: LLStack<T>?
    
    func push(val: T) {
        let newNode = LLStack(val: val)
        if top == nil {
            top = newNode
        } else {
            let currentTop = top
            top = newNode
            top?.next = currentTop
        }
    }
    
    func pop() -> T? {
        if top == nil {
            return nil
        }
        
        let currentTop = top
        if top?.next != nil {
            top = top?.next
        } else {
            top = nil
        }
        return currentTop?.data
    }
    
    func peek() -> T? {
        return top?.data
    }
    
    func isEmpty() -> Bool {
        return (top == nil)
    }
}

var llStack = LLStackImplemetation<String>()
llStack.push(val: "Hi")
llStack.push(val: "Narendra")

llStack.pop()
llStack.peek()
llStack.isEmpty()
